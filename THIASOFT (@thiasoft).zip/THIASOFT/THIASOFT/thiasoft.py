from telethon import TelegramClient, events, errors
from telethon.tl import types
import asyncio
from telethon.tl.types import Message


async def animated_loading(event):
    for cursor in '|/-\\':
        print(f'\u001b[31m{cursor} Loading... \u001b[0m', end='\r')
        await asyncio.sleep(3)  # задержка на аним


async def print_red(text):
    RED = '\u001b[31m'
    RESET = '\u001b[0m'
    print(RED + text + RESET)


async def start():
    ascii_art = r'''
     ________  __    __  ______   ______    ______    ______   ________  ________
    /        |/  |  /  |/      | /      \  /      \  /      \ /        |/        |
    $$$$$$$$/$$ |  $$ |$$$$$$/ /$$$$$$  |/$$$$$$  |/$$$$$$  |$$$$$$$$/ $$$$$$$$/
       $$ |  $$ |__$$ |  $$ |  $$ |__$$ |$$ \__$$/ $$ |  $$ |$$ |__       $$ |
       $$ |  $$    $$ |  $$ |  $$    $$ |$$      \ $$ |  $$ |$$    |      $$ |
       $$ |  $$$$$$$$ |  $$ |  $$$$$$$$ | $$$$$$  |$$ |  $$ |$$$$$/       $$ |
       $$ |  $$ |  $$ | _$$ |_ $$ |  $$ |/  \__$$ |$$ \__$$ |$$ |         $$ |
       $$ |  $$ |  $$ |/ $$   |$$ |  $$ |$$    $$/ $$    $$/ $$ |         $$ |
       $$/   $$/   $$/ $$$$$$/ $$/   $$/  $$$$$$/   $$$$$$/  $$/          $$/
    '''
    await animated_loading(None)
    print("\033[F\033[K", end="")  # Очистка сообщения о загрузке *уборка*
    await print_red(ascii_art)


async def delete_own_messages(client):
    async for dialog in client.iter_dialogs():
        try:
            async for message in client.iter_messages(dialog.input_entity, from_user='me'):
                await client.delete_messages(dialog.input_entity, message.id)
            print(f"All own messages deleted in {dialog.name}.")
        except Exception as e:
            print(f"Failed to delete own messages in {dialog.name} with error: {e}")


async def show_menu():
    MENU = (
        "\u001b[31m0. Return to main menu\n"
        "1. Delete all your messages\n"
        "2. Scan a group\n"
        "3. Auto check messages\n"
        "\u001b[0mSelect an option: "
    )
    print(MENU, end='')
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, input)



async def get_chat_id(client, chat_username):
    try:
        entity = await client.get_entity(chat_username)
        return entity.id
    except Exception as e:
        print(f"Failed to get chat ID: {e}")
        return None


async def print_red(text):
    RED = '\u001b[31m'
    RESET = '\u001b[0m'
    print(RED + text + RESET)


async def analyze_group(client, group_entity):
    try:
        entity = await client.get_entity(group_entity)
        if entity:
            if hasattr(entity, 'broadcast') and entity.broadcast:
                await print_red(f"Channel Type: {entity.title}")
                await print_red(f"Is Public: {entity.megagroup}")
                await print_red(f"Message Timer: {entity.restriction_reason}")
                await print_red("Channel Info:")
                await print_red(f" - Broadcast: {entity.broadcast}")
                await print_red(f" - Megagroup: {entity.megagroup}")
            else:
                participants = await client.get_participants(entity)
                bot_count = sum(1 for participant in participants if participant.bot)

                messages = await client.get_messages(entity, limit=1)
                first_message_date = messages[0].date.strftime("%Y-%m-%d %H:%M:%S") if messages else "Not available"

                all_messages = await client.get_messages(entity, limit=1, reverse=True)
                last_message_date = all_messages[0].date.strftime("%Y-%m-%d %H:%M:%S") if all_messages else "Not available"

                await print_red(f"Group Type: {entity.title}")
                await print_red(f"Is Public: {entity.megagroup}")
                await print_red(f"Message Timer: {entity.restriction_reason}")
                await print_red(f"Bot Count: {bot_count}")
                await print_red(f"Total Participants: {len(participants)}")
                await print_red(f"First Message Date: {first_message_date}")
                await print_red(f"Last Message Date: {last_message_date}")
                await print_red("Permissions:")
                await print_red(f" - Send Messages: {entity.permissions.send_messages}")
                await print_red(f" - Send Media: {entity.permissions.send_media}")
        else:
            await print_red("Group not found.")

    except errors.FloodWaitError as e:
        await print_red(f"Rate limited. Please wait {e.seconds} seconds.")
    except errors.RPCError as e:
        await print_red(f"Failed to analyze group: {e}")
    except Exception as e:
        await print_red(f"An unexpected error occurred: {e}")


async def scan_group(client):
    group_entity = input("Enter the group/channel username or ID: ")
    await analyze_group(client, group_entity)

async def auto_check_messages(client, message_to_find):
    async for dialog in client.iter_dialogs():
        try:
            entity = await client.get_entity(dialog.input_entity)
            if entity:
                if isinstance(entity, types.Channel):
                    await check_channel_messages(client, entity, message_to_find)
            elif isinstance(entity, types.Chat):
                await check_chat_messages(client, entity, message_to_find)
            elif isinstance(entity, types.User):
                await check_user_messages(client, entity, message_to_find)
        except Exception as e:
            print(f"Не удалось проверить сообщения в {dialog.name} из-за ошибки: {e}")

async def check_channel_messages(client, channel, message_to_find):
    try:
        async for message in client.iter_messages(channel):
            if message.text and message_to_find.lower() in message.text.lower():
                link = f"https://t.me/{channel.username}/{message.id}"
                print(f"Найдено сообщение в {channel.title}: {link}")
                return
    except Exception as e:
        print(f"Ошибка при поиске сообщений в {channel.title}: {e}")

async def check_chat_messages(client, chat, message_to_find):
    try:
        async for message in client.iter_messages(chat):
            if message.text and message_to_find.lower() in message.text.lower():
                link = f"https://t.me/{chat.username}/{message.id}"
                print(f"Найдено сообщение в {chat.title}: {link}")
                return
    except Exception as e:
        print(f"Ошибка при поиске сообщений в {chat.title}: {e}")

async def check_user_messages(client, user, message_to_find):
    try:
        async for message in client.iter_messages(user):
            if message.text and message_to_find.lower() in message.text.lower():
                link = f"https://t.me/{user.username}/{message.id}"
                print(f"Найдено сообщение у {user.first_name} {user.last_name}: {link}")
                return
    except Exception as e:
        print(f"Ошибка при поиске сообщений у {user.first_name} {user.last_name}: {e}")


async def main():
    api_id = input("\u001b[31mEnter your API ID: \u001b[0m")
    api_hash = input("\u001b[31mEnter your API Hash: \u001b[0m")

    try:

        if not api_id.isdigit() or not api_hash:
            print("Invalid API ID or API Hash. Exiting.")
            return

        session_name = 'userbot_session'
        client = TelegramClient(session_name, int(api_id), api_hash)
        client.parse_mode = 'html'

        #подключение к Telegram
        if not client.is_connected():
            await client.connect()

        #авторизация
        if not await client.is_user_authorized():
            phone = input("\u001b[31mEnter your phone number: \u001b[0m")
            await client.send_code_request(phone)
            code = input("\u001b[31mEnter the confirmation code: \u001b[0m")
            await client.sign_in(phone, code)

        while True:
            await start()
            choice = await show_menu()

            if choice == "0":
                continue
            elif choice == "1":
                confirmation = input("Вы уверены, что хотите удалить все свои сообщения? (Y/N): ")
                if confirmation.lower() == 'y':
                    await delete_own_messages(client)
                else:
                    print("Удаление отменено.")
            elif choice == "2":
                await scan_group(client)
            elif choice == "3":
                message_to_find = input("Введите текст сообщения для авто-поиска: ")
                await auto_check_messages(client, message_to_find)
            else:
                print("Неверный выбор.")

    except errors.FloodWaitError as e:
        print(f"Rate limited. Please wait {e.seconds} seconds.")
    except errors.RPCError as e:
        print(f"Telegram error: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

    finally:
        try:
            await client.disconnect()
        except Exception as e:
            print(f"An error occurred while disconnecting: {e}")

if __name__ == "__main__":
    asyncio.run(main())